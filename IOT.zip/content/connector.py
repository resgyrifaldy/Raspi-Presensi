from mfrc522 import SimpleMFRC522
import RPi.GPIO as GPIO
import time
import mysql.Connector
mysql = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",
    database="iot_rfid"
)


reader = SimpleMFRC522()

while True:
    try:
        id, text = reader.read()
        mycursor = mysql.cursor()
        print(id)
        print(text)
        time.sleep(10)
        sql = "insert into data(nama,user_id) values(%s,%s)"
        val = ("text", "id")

        mycursor.execute(sql, val)

        mysql.commit()

        print("Data Berhasil Ditambahkan")
