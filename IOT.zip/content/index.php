<?php
session_start();
if ($_SESSION['status'] != "login") {
  header("location:../index.php?pesan=belum_login");
}
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="style.css">

  <title>IOT Presensi</title>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg navbar-light bg-dark">
    <a class="navbar-brand font-weight-bold text-light" href="https://www.jquery-az.com/">RASPI-SCAN</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#demo-navbar" aria-controls="demo-navbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="demo-navbar">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link text-warning" href="#">PROFILE<span class="sr-only">(current)</span></a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0" action="../logout.php" method="post">
        <button class="btn btn-outline-warning my-2 my-sm-0" type="submit">Logout</button>
      </form>
    </div>
  </nav>
  <!-- END NAVBAR -->
  <div class="container-fluid">

    <div class="row">
      <div class="col ml-5 mt-5">
        <div class="card" style="width: 25rem;">
          <div class="card-header text">
            Dashboard
          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item"><a href="#" class="d-block p-2 bg-primary text-white">Presensi Manual <b>F3</b></a></li>
            <li class="list-group-item"><a href="#" class="d-block p-2 bg-primary text-white">Edit Materi <b>F4</b></a></li>
            <li class="list-group-item"><a href="#" class="d-block p-2 bg-primary text-white">Presensi QR-Code <b>F6</b></a></li>
            <li class="list-group-item"><a href="#" class="d-block p-2 bg-primary text-white">Exit <b>F7</b></a></li>
          </ul>
          <div class="card-header text">
          </div>
          <ul class="card list-group list-group-flush" style="width: 25rem;">
            <li class="list-group-item text-center">STATUS</li>
            <li class="list-group-item text-center">
              <div class="jam-digital-malasngoding">
                <div class="kotak">
                  <p id="jam"></p>
                </div>
                <div class="kotak">
                  <p id="menit"></p>
                </div>
                <div class="kotak">
                  <p id="detik"></p>
                </div>
              </div>
            </li>
            <li class="list-group-item text-center">Selamat datang <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </div>
      <div class="col-8 mr-4 mt-5">
        <table class="table">
          <tr>
            <th scope="col">No</th>
            <th scope="col">Nama</th>
            <th scope="col">NIM</th>
            <th scope="col">Tanggal</th>
            <th scope="col">Action</th>
          </tr>
          <?php
          include 'config.php';
          $no = 1;
          $data = mysqli_query($connection, "select * from data");
          while ($d = mysqli_fetch_array($data)) {
            ?>
            <tr>
              <td scope="row"><?php echo $no++; ?></td>
              <td><?php echo $d["nama"]; ?></td>
              <td><?php echo $d["user_id"]; ?></td>
              <td><?php echo $d["date"]; ?></td>
              <td><a class="btn btn-danger" href="hapus.php?id=<?php echo $d['id']; ?>">Hapus</a></td>
            </tr>
          <?php
          }
          ?>
        </table>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <!-- <script language="javascript">
    setTimeout(function() {
      window.location.reload(1);
    }, 10000);
  </script> -->
  <script>
    window.setTimeout("waktu()", 1000);

    function waktu() {
      var waktu = new Date();
      setTimeout("waktu()", 1000);
      document.getElementById("jam").innerHTML = waktu.getHours();
      document.getElementById("menit").innerHTML = waktu.getMinutes();
      document.getElementById("detik").innerHTML = waktu.getSeconds();
    }
  </script>
</body>

</html>